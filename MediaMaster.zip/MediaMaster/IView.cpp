#include "IView.hpp"
#include "IController.hpp"
#include "PlayList.hpp"
#include "File.hpp"
#include <iostream>
#include <iomanip>
#include <sstream>

IView::IView(std::shared_ptr<IController> controller) : controller(controller) {
    // Nothing else to initialize
}

void IView::ShowCurrentMedia() {
    std::cout << "\n=============================================== CURRENT MEDIA ===============================================" << std::endl;
    
    // Show current playlist information
    auto currentPlaylist = controller->GetCurrentPlaylist();
    if (currentPlaylist) {
        std::cout << "Current Playing From PlayList: " << controller->GetCurrentPlaylistIndex() << ". \"" << currentPlaylist->GetName() << "\"" << std::endl;
        std::cout << "PlayList Media:" << std::endl;
        
        // List files in the current playlist (up to 3 for clean display as in the mockups)
        const auto& files = currentPlaylist->GetFiles();
        size_t displayLimit = std::min(files.size(), size_t(3));
        for (size_t i = 0; i < displayLimit; i++) {
            std::string title = files[i]->getMetadata().Title;
            if (title.empty()) {
                title = files[i]->getFileName();
            }
            std::cout << "    " << i + 1 << ". " << title << std::endl;
        }
        if (files.size() > 3) {
            std::cout << "    ... and " << files.size() - 3 << " more files" << std::endl;
        }
    } else {
        std::cout << "No playlist selected." << std::endl;
    }
    
    std::cout << std::endl; // Empty line as per mockups
    
    // Show current media information
    auto currentMedia = controller->GetCurrentMedia();
    if (currentMedia) {
        std::string title = currentMedia->getMetadata().Title;
        if (title.empty()) {
            title = currentMedia->getFileName();
        }
        std::cout << "Current Media: " << controller->GetCurrentMediaIndex() + 1 << ". \"" << title << "\"" << std::endl;
        std::cout << "Metadata: " << std::endl;
        
        // Display basic playback controls as per mockups
        std::cout << "    'p': Pause/Resume" << std::endl;
        std::cout << "    'n': next in PlayList" << std::endl;
        std::cout << "    'b': previous in PlayList" << std::endl;
    } else {
        std::cout << "No media is currently playing." << std::endl;
        
        // Still show playback controls even if no media is playing
        std::cout << "Metadata: " << std::endl;
        std::cout << "    'p': Pause/Resume" << std::endl;
        std::cout << "    'n': next in PlayList" << std::endl;
        std::cout << "    'b': previous in PlayList" << std::endl;
    }
    
    std::cout << "\n>> Enter: ";
}

std::string IView::FormatDuration(double seconds) const {
    int totalSeconds = static_cast<int>(seconds);
    int minutes = totalSeconds / 60;
    int remainingSeconds = totalSeconds % 60;
    
    std::stringstream ss;
    ss << minutes << ":" << std::setw(2) << std::setfill('0') << remainingSeconds;
    return ss.str();
}

std::shared_ptr<IController> IView::GetController() const {
    return controller;
}

void IView::ShowMainMenu() {
    // Common code for displaying the main menu
    std::cout << "=============================================== MEDIA PLAYER ===============================================" << std::endl;
    std::cout << std::endl;
    std::cout << "'1'. Play from current directory (PlayList number 0)" << std::endl;
    std::cout << "'2'. Play a media in Current Playing List" << std::endl;
    std::cout << "'3'. Play a PlayList" << std::endl;
    std::cout << std::endl;
    std::cout << "'4'. Show current directory (PlayList number 0)" << std::endl;
    std::cout << "'5'. Show a PlayList from Media Library" << std::endl;
    std::cout << "'6'. Show Media Library" << std::endl;
    std::cout << std::endl;
    std::cout << "'7'. Delete a PlayList from Media Library" << std::endl;
    std::cout << "'8'. Add a PlayList to Media Library" << std::endl;
    std::cout << "'a'. add Media to PlayList in Media Library" << std::endl;
    std::cout << "'r'. remove Media from PlayList in Media Library" << std::endl;
    std::cout << "'c'. change current directory" << std::endl;
    std::cout << std::endl;
    std::cout << "'0'. Exit Media Player" << std::endl;
    std::cout << std::endl;
    
    // Show current media information (reuse existing method)
    ShowCurrentMedia();
}
