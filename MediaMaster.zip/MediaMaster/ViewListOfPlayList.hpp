#pragma once
#include "IView.hpp"
#include <string>

/**
 * @class ViewListOfPlayList
 * @brief View for displaying and managing the list of playlists.
 */
class ViewListOfPlayList : public IView {
private:
    int screen_type;
    std::string message;

public:
    /**
     * @brief Constructor that initializes the view with a controller.
     * @param controller The controller for this view.
     * @param screen_type The type of screen to display (corresponds to specific view layouts).
     * @param message Optional message to display on the screen.
     */
    ViewListOfPlayList(std::shared_ptr<IController> controller, int screen_type = 0, const std::string& message = "");

    /**
     * @brief Shows the list of playlists screen.
     */
    void ShowScreen() override;
};