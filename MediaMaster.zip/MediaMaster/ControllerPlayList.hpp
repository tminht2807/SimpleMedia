#pragma once
#include "IController.hpp"

/**
 * @class ControllerPlayList
 * @brief Controller for handling playlist-specific operations.
 */
class ControllerPlayList : public IController {
public:
    /**
     * @brief Constructor that initializes the controller.
     */
    ControllerPlayList();

    /**
     * @brief Destructor.
     */
    ~ControllerPlayList() override;

    /**
     * @brief Handles user input for playlist-specific operations.
     */
    void HandleCases() override;

    /**
     * @brief Shows the contents of a playlist.
     * @param index The index of the playlist to show.
     */
    void ShowPlayList(size_t index);

    /**
     * @brief Plays a media file from a specific playlist.
     * @param playlistIndex The index of the playlist.
     */
    void PlayFromPlayList(size_t playlistIndex);

    /**
     * @brief Adds a media file to a playlist.
     * @param playlistIndex The index of the playlist to add the media file to.
     */
    void AddToPlayList(size_t playlistIndex);

    /**
     * @brief Removes a media file from a playlist.
     * @param playlistIndex The index of the playlist to remove the media file from.
     */
    void RemoveFromPlayList(size_t playlistIndex);

    /**
     * @brief Changes the current directory and updates the first playlist.
     */
    void ChangeDirectory();
    
    /**
     * @brief Shows the contents of the current directory as a playlist.
     */
    void ShowCurrentDirectory();
};
