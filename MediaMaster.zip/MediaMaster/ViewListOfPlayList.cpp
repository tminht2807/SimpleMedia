#include "ViewListOfPlayList.hpp"
#include "IController.hpp"
#include <iostream>
#include <cstdlib>

ViewListOfPlayList::ViewListOfPlayList(std::shared_ptr<IController> controller, int screen_type, const std::string& message)
    : IView(controller), screen_type(screen_type), message(message) {
    // Nothing else to initialize
}

void ViewListOfPlayList::ShowScreen() {
    // Clear the screen
    system("clear");
    
    std::cout << "=============================================== MEDIA PLAYER ===============================================" << std::endl;
    std::cout << std::endl;
    
    // Get playlists from controller once
    std::vector<std::shared_ptr<PlayList>> playlists;
    try {
        playlists = controller->GetListOfPlayList();
    } catch (const std::exception& e) {
        std::cerr << "Error getting playlists: " << e.what() << std::endl;
    }
    
    // Display content based on screen type
    switch (screen_type) {
        case 0: // Main list of playlists view
            std::cout << "Media Library (PlayLists):" << std::endl;
            // Display the list of playlists
            if (playlists.empty()) {
                std::cout << "No playlists available." << std::endl;
            } else {
                for (size_t i = 0; i < playlists.size(); ++i) {
                    std::cout << i + 1 << ". " << playlists[i]->GetName() << std::endl;
                }
            }
            std::cout << std::endl;
            std::cout << "'0'. Return to Main Menu" << std::endl;
            break;
            
        case 3: // Play a playlist
            std::cout << "Play a Playlist:" << std::endl;
            // Display the list of playlists
            if (playlists.empty()) {
                std::cout << "No playlists available." << std::endl;
            } else {
                for (size_t i = 0; i < playlists.size(); ++i) {
                    std::cout << i + 1 << ". " << playlists[i]->GetName() << std::endl;
                }
            }
            std::cout << std::endl;
            std::cout << message << std::endl;
            std::cout << "'0'. Return to Main Menu" << std::endl;
            break;
            
        case 5: // Show a playlist
            std::cout << "Show a Playlist:" << std::endl;
            // Display the list of playlists
            if (playlists.empty()) {
                std::cout << "No playlists available." << std::endl;
            } else {
                for (size_t i = 0; i < playlists.size(); ++i) {
                    std::cout << i + 1 << ". " << playlists[i]->GetName() << std::endl;
                }
            }
            std::cout << std::endl;
            std::cout << message << std::endl;
            std::cout << "'0'. Return to Main Menu" << std::endl;
            break;
            
        case 7: // Delete a playlist
            std::cout << "Delete a Playlist:" << std::endl;
            // Display the list of playlists
            if (playlists.empty()) {
                std::cout << "No playlists available." << std::endl;
            } else {
                for (size_t i = 0; i < playlists.size(); ++i) {
                    std::cout << i + 1 << ". " << playlists[i]->GetName() << std::endl;
                }
            }
            std::cout << std::endl;
            std::cout << message << std::endl;
            std::cout << "'0'. Return to Main Menu" << std::endl;
            break;
            
        case 8: // Add a playlist
            std::cout << "Enter name for the new PlayList" << std::endl;
            std::cout << std::endl;
            if (!message.empty() && message != "Enter name for the new PlayList") {
                std::cout << message << std::endl;
                std::cout << std::endl;
            }
            std::cout << "'0'. Return" << std::endl;
            break;
            
        case 97: // Add media to playlist
            std::cout << "Add Media to Playlist:" << std::endl;
            // Display the list of playlists
            if (playlists.empty()) {
                std::cout << "No playlists available." << std::endl;
            } else {
                for (size_t i = 0; i < playlists.size(); ++i) {
                    std::cout << i + 1 << ". " << playlists[i]->GetName() << std::endl;
                }
            }
            std::cout << std::endl;
            std::cout << message << std::endl;
            std::cout << "'0'. Return to Main Menu" << std::endl;
            break;
            
        case 98: // Remove media from playlist
            std::cout << "Remove Media from Playlist:" << std::endl;
            // Display the list of playlists
            if (playlists.empty()) {
                std::cout << "No playlists available." << std::endl;
            } else {
                for (size_t i = 0; i < playlists.size(); ++i) {
                    std::cout << i + 1 << ". " << playlists[i]->GetName() << std::endl;
                }
            }
            std::cout << std::endl;
            std::cout << message << std::endl;
            std::cout << "'0'. Return to Main Menu" << std::endl;
            break;
            
        default:
            std::cout << "Unknown screen type: " << screen_type << std::endl;
            break;
    }
    
    // Show current media information
    ShowCurrentMedia();
}