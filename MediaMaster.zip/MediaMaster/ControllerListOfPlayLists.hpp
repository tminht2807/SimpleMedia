#pragma once
#include "IController.hpp"

/**
 * @class ControllerListOfPlayLists
 * @brief Controller for handling operations on the list of playlists.
 */
class ControllerListOfPlayLists : public IController {
public:
    /**
     * @brief Constructor that initializes the controller.
     */
    ControllerListOfPlayLists();

    /**
     * @brief Destructor.
     */
    ~ControllerListOfPlayLists() override;

    /**
     * @brief Handles user input for playlist list operations.
     */
    void HandleCases() override;

    /**
     * @brief Shows the list of all playlists.
     */
    void ShowListOfPlayLists();

    /**
     * @brief Adds a new playlist.
     */
    void AddPlayList();

    /**
     * @brief Removes a playlist.
     */
    void RemovePlayList();

    /**
     * @brief Plays media from a selected playlist.
     */
    void PlayPlayList();
    
    /**
     * @brief Plays media from the current directory (Playlist 0).
     */
    void PlayCurrentDirectory();

    /**
     * @brief Shows the contents of a selected playlist.
     */
    void ShowPlayList();

    /**
     * @brief Adds media to a selected playlist.
     */
    void AddMediaToPlayList();

    /**
     * @brief Removes media from a selected playlist.
     */
    void RemoveMediaFromPlayList();
};
