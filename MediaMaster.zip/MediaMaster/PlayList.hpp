#pragma once
#include "File.hpp"
#include <vector>
#include <memory>
#include <string>

/**
 * @class PlayList
 * @brief Class to represent a playlist of media files.
 */
class PlayList {
private:
    std::string Name;
    std::vector<std::shared_ptr<File>> ListFiles;

public:
    /**
     * @brief Constructor that initializes the playlist with a name.
     * @param name The name of the playlist.
     */
    PlayList(const std::string& name);

    /**
     * @brief Gets the name of the playlist.
     * @return The name of the playlist.
     */
    std::string GetName() const;

    /**
     * @brief Sets the name of the playlist.
     * @param name The new name for the playlist.
     */
    void SetName(const std::string& name);

    /**
     * @brief Gets the list of files in the playlist.
     * @return The vector of files in the playlist.
     */
    const std::vector<std::shared_ptr<File>>& GetFiles() const;

    /**
     * @brief Adds a file to the playlist.
     * @param filePath The path to the file to add.
     * @return True if the file was successfully added, false otherwise.
     */
    bool AddFile(const std::string& filePath);

    /**
     * @brief Removes a file from the playlist.
     * @param index The index of the file to remove.
     * @return True if the file was successfully removed, false otherwise.
     */
    bool RemoveFile(size_t index);

    /**
     * @brief Clears all files from the playlist.
     */
    void ClearFiles();

    /**
     * @brief Gets the number of files in the playlist.
     * @return The number of files in the playlist.
     */
    size_t Size() const;

    /**
     * @brief Checks if the playlist is empty.
     * @return True if the playlist is empty, false otherwise.
     */
    bool IsEmpty() const;
};
