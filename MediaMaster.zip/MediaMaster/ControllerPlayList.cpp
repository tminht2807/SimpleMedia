#include "ControllerPlayList.hpp"
#include "ViewPlayList.hpp"
#include <iostream>
#include <string>
#include <limits>
#include <filesystem>

ControllerPlayList::ControllerPlayList() : IController() {
    // Nothing else to initialize
}

ControllerPlayList::~ControllerPlayList() {
    // Nothing to clean up
}

void ControllerPlayList::HandleCases() {
    char choice;
    bool exitMenu = false;
    
    // Return to main menu when '0' is entered
    while (!exitMenu) {
        // Show playlist screen
        std::cout << "=============================================== MEDIA PLAYER ===============================================" << std::endl;
        std::cout << std::endl;
        std::cout << "PlayList Options:" << std::endl;
        std::cout << "'1'. Play a media file" << std::endl;
        std::cout << "'2'. Add media to playlist" << std::endl;
        std::cout << "'3'. Remove media from playlist" << std::endl;
        std::cout << "'4'. Show playlist contents" << std::endl;
        std::cout << "'c'. Change current directory" << std::endl;
        std::cout << std::endl;
        std::cout << "'0'. Return to Main Menu" << std::endl;
        std::cout << std::endl;
        
        // Show current media information
        std::cout << "=============================================== CURRENT MEDIA ===============================================" << std::endl;
        
        auto currentPlaylist = GetCurrentPlaylist();
        auto currentMedia = GetCurrentMedia();
        
        std::cout << "Current Playing From PlayList: " << GetCurrentPlaylistIndex() << ". \"" 
                << (currentPlaylist ? currentPlaylist->GetName() : "Unknown") << "\"" << std::endl;
        
        std::cout << "PlayList Media:" << std::endl;
        if (currentPlaylist && !currentPlaylist->GetFiles().empty()) {
            const auto& files = currentPlaylist->GetFiles();
            for (size_t i = 0; i < files.size(); ++i) {
                std::cout << "    " << i + 1 << ". " << files[i]->getFileName() << std::endl;
            }
        } else {
            std::cout << "    No media in playlist" << std::endl;
        }
        
        std::cout << std::endl;
        std::cout << "Current Media: " << GetCurrentMediaIndex() + 1 << ". \"" 
                << (currentMedia ? currentMedia->getFileName() : "None") << "\"" << std::endl;
        
        std::cout << "Metadata: " << std::endl;
        
        std::cout << "    'p': Pause/Resume" << std::endl;
        std::cout << "    'n': next in PlayList" << std::endl;
        std::cout << "    'b': previous in PlayList" << std::endl;
        
        std::cout << ">> Enter: ";
        std::cin >> choice;
        
        if (choice == '0') {
            exitMenu = true;
        } else {
            switch (choice) {
                case '1': // Play a media file
                    PlayFromPlayList(GetCurrentPlaylistIndex());
                    break;
                case '2': // Add media to playlist
                    AddToPlayList(GetCurrentPlaylistIndex());
                    break;
                case '3': // Remove media from playlist 
                    RemoveFromPlayList(GetCurrentPlaylistIndex());
                    break;
                case '4': // Show playlist
                    ShowCurrentDirectory();
                    break;
                case 'c': // Change current directory
                    ChangeDirectory();
                    break;
                case 'p': // Handle media commands
                case 'n':
                case 'b':
                    ProcessMediaCommand(choice);
                    break;
                default:
                    std::cerr << "Invalid choice in ControllerPlayList." << std::endl;
            }
        }
    }
}

void ControllerPlayList::ShowPlayList(size_t index) {
    // Check if index is valid
    if (index >= List_PL.size()) {
        std::cerr << "Invalid playlist index." << std::endl;
        return;
    }
    
    int screenType = (index == 0) ? 3 : 2; // 3 for current directory, 2 for specific playlist
    std::string prompt = (index == 0) ? "Enter index of media file to play:" : "Enter index of media file in playlist to play:";
    
    // Create and set the view
    auto view = std::make_shared<ViewPlayList>(std::shared_ptr<IController>(this, [](IController*){}), screenType, prompt, index);
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    int mediaIndex;
    std::cin >> mediaIndex;
    
    if (mediaIndex == 0) {
        // Return to main menu
        return;
    }
    
    // Adjust index (UI shows 1-based, internal is 0-based)
    mediaIndex--;
    
    // Play the selected media
    if (mediaIndex >= 0 && mediaIndex < static_cast<int>(List_PL[index]->Size())) {
        PlayMedia(index, mediaIndex);
    } else {
        std::cerr << "Invalid media index." << std::endl;
    }
}

void ControllerPlayList::PlayFromPlayList(size_t playlistIndex) {
    // Check if index is valid
    if (playlistIndex >= List_PL.size()) {
        std::cerr << "Invalid playlist index." << std::endl;
        return;
    }
    
    // Create and set the view
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        2, // Show specific playlist
        "Enter index of media file to play:",
        playlistIndex
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    int mediaIndex;
    std::cin >> mediaIndex;
    
    if (mediaIndex == 0) {
        // Return to main menu
        return;
    }
    
    // Adjust index (UI shows 1-based, internal is 0-based)
    mediaIndex--;
    
    // Play the selected media
    if (mediaIndex >= 0 && mediaIndex < static_cast<int>(List_PL[playlistIndex]->Size())) {
        PlayMedia(playlistIndex, mediaIndex);
    } else {
        std::cerr << "Invalid media index." << std::endl;
    }
}

void ControllerPlayList::AddToPlayList(size_t playlistIndex) {
    // Check if index is valid
    if (playlistIndex >= List_PL.size()) {
        std::cerr << "Invalid playlist index." << std::endl;
        return;
    }
    
    // Create custom view for adding media
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        97, // Screen type for adding media
        "Enter directory of Media file/folder to add",
        playlistIndex
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    std::string path;
    
    // Clear the buffer only if there are characters to clear
    if (std::cin.rdbuf()->in_avail() > 0) {
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    
    std::getline(std::cin, path);
    
    if (path == "0") {
        // Return to main menu
        return;
    }
    
    // Check if path is a directory or file
    if (std::filesystem::is_directory(path)) {
        // Add all media files from the directory
        if (AddMediaFilesFromFolder(playlistIndex, path)) {
            std::cout << "Successfully added media files from directory." << std::endl;
            // Prompt for a key to continue
            std::cout << "Press any key to continue..." << std::endl;
            
            // Only wait for input if there's no leftover in the buffer
            if (std::cin.rdbuf()->in_avail() == 0) {
                std::cin.get();
            }
        } else {
            std::cerr << "Failed to add media files from directory." << std::endl;
            // Prompt for a key to continue
            std::cout << "Press any key to continue..." << std::endl;
            
            // Only wait for input if there's no leftover in the buffer
            if (std::cin.rdbuf()->in_avail() == 0) {
                std::cin.get();
            }
        }
    } else {
        // Add the file to the playlist
        if (IController::AddToPlayList(playlistIndex, path)) {
            std::cout << "Successfully added media file to playlist." << std::endl;
            // Prompt for a key to continue
            std::cout << "Press any key to continue..." << std::endl;
            
            // Only wait for input if there's no leftover in the buffer
            if (std::cin.rdbuf()->in_avail() == 0) {
                std::cin.get();
            }
        } else {
            std::cerr << "Failed to add media file to playlist." << std::endl;
            // Prompt for a key to continue
            std::cout << "Press any key to continue..." << std::endl;
            
            // Only wait for input if there's no leftover in the buffer
            if (std::cin.rdbuf()->in_avail() == 0) {
                std::cin.get();
            }
        }
    }
}

void ControllerPlayList::RemoveFromPlayList(size_t playlistIndex) {
    // Check if index is valid
    if (playlistIndex >= List_PL.size()) {
        std::cerr << "Invalid playlist index." << std::endl;
        return;
    }
    
    // Create and set the view
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        2, // Show specific playlist
        "Enter index of media to remove:",
        playlistIndex
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    int mediaIndex;
    std::cin >> mediaIndex;
    
    if (mediaIndex == 0) {
        // Return to main menu
        return;
    }
    
    // Adjust index (UI shows 1-based, internal is 0-based)
    mediaIndex--;
    
    // Remove the selected media
    if (mediaIndex >= 0 && mediaIndex < static_cast<int>(List_PL[playlistIndex]->Size())) {
        if (IController::RemoveFromPlayList(playlistIndex, mediaIndex)) {
            std::cout << "Successfully removed media from playlist." << std::endl;
        } else {
            std::cerr << "Failed to remove media from playlist." << std::endl;
        }
    } else {
        std::cerr << "Invalid media index." << std::endl;
    }
}

void ControllerPlayList::ChangeDirectory() {
    // Create custom view for changing directory
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        98, // Screen type for changing directory
        "Enter folder path to change current directory:",
        0
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    std::string path;
    
    // Clear the buffer only if there are characters to clear
    if (std::cin.rdbuf()->in_avail() > 0) {
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    
    std::getline(std::cin, path);
    
    if (path == "0") {
        // Return to main menu
        return;
    }
    
    // Update the current directory
    UpdateCurrentDirectory(path);
    
    // Show confirmation and wait for user input
    std::cout << "Directory changed to: " << path << std::endl;
    std::cout << "Press any key to continue..." << std::endl;
    
    // Only wait for input if there's no leftover in the buffer
    if (std::cin.rdbuf()->in_avail() == 0) {
        std::cin.get();
    }
}

void ControllerPlayList::ShowCurrentDirectory() {
    // Simply delegate to the ShowPlayList method with index 0 (current directory)
    ShowPlayList(0);
}
