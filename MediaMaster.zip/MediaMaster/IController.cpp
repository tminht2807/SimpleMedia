#include "IController.hpp"
#include <filesystem> // C++17 filesystem library
#include <iostream> // For error messages

// Include SDL headers in the implementation file only
#include <SDL2/SDL.h>
#include "include/SDL2/SDL_mixer.h"

// Static member initialization
std::vector<std::shared_ptr<PlayList>> IController::List_PL;

// Constructor
IController::IController()
    : currentIndex(0), currentPlaylistIndex(0), currentMusic(nullptr), currentTime(0.0), isPlaying(false), isPaused(false) {
    instance = this; // Set the singleton instance
    try {
        // Retrieve the current directory and save it
        std::string tempDirectory = std::filesystem::current_path().string();

        // Initialize the current directory and media files
        UpdateCurrentDirectory(tempDirectory);
        
        // Create initial playlist for the current directory
        if (List_PL.empty()) {
            AddPlayList("Current Directory");
            AddMediaFilesFromFolder(0, currentDirectory);
        }
    } catch (const std::exception& e) {
        std::cerr << "Error initializing controller: " << e.what() << std::endl;
    }
    
    // Initialize SDL2
    if (!InitializeSDL()) {
        std::cerr << "Failed to initialize SDL2." << std::endl;
        throw std::runtime_error("SDL2 initialization failed");
    }
}

// Destructor
IController::~IController() {
    if (currentMusic) {
        Mix_FreeMusic(currentMusic);
    }
    Mix_CloseAudio();
    SDL_Quit();
}

// SDL2 Initialization Method
bool IController::InitializeSDL() {
    if (SDL_Init(SDL_INIT_AUDIO) < 0) {
        std::cerr << "Failed to initialize SDL: " << SDL_GetError() << std::endl;
        return false;
    }

    // Initialize SDL_mixer with audio format settings
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        std::cerr << "Failed to initialize SDL_mixer" << std::endl;
        SDL_Quit();
        return false;
    }

    return true; // Initialization successful
}

// Static callback function to handle the end of media playback
void IController::StaticOnMediaFinished() {
    if (instance) {
        instance->OnMediaFinished();
    }
}

// Callback function to handle the end of media playback
void IController::OnMediaFinished() {
    std::cout << "Media playback finished." << std::endl;

    // Call the next media function to move to the next track
    NextMedia();
}

// Play Media Method
bool IController::PlayMedia(size_t playlistIndex, size_t mediaIndex) {
    try {
        // Check if playlists vector is empty
        if (List_PL.empty()) {
            std::cerr << "No playlists available." << std::endl;
            return false;
        }
        
        // Check if playlistIndex is valid
        if (playlistIndex >= List_PL.size()) {
            std::cerr << "Invalid playlist index: " << playlistIndex << std::endl;
            return false;
        }
        
        // Get the playlist
        auto playlist = List_PL[playlistIndex];
        
        // Check if the playlist is empty
        if (playlist->GetFiles().empty()) {
            std::cerr << "Playlist is empty." << std::endl;
            return false;
        }
        
        // Check if mediaIndex is valid
        if (mediaIndex >= playlist->GetFiles().size()) {
            std::cerr << "Invalid media index: " << mediaIndex << std::endl;
            return false;
        }
        
        // Update current indices
        currentPlaylistIndex = playlistIndex;
        currentIndex = mediaIndex;
        
        // Get the file path of the selected media file
        std::string filePath = playlist->GetFiles()[mediaIndex]->getFilePath();

        // Free the previous music object if any
        if (currentMusic) {
            Mix_FreeMusic(currentMusic);
        }

        // Load the media file into SDL_mixer
        currentMusic = Mix_LoadMUS(filePath.c_str());
        if (!currentMusic) {
            std::cerr << "Failed to load media file" << std::endl;
            return false;
        }

        // Set the callback for when the music finishes
        Mix_HookMusicFinished(StaticOnMediaFinished);

        // Start playing the media file
        if (Mix_PlayMusic(currentMusic, 0) == -1) {
            std::cerr << "Failed to play media" << std::endl;
            return false;
        }

        isPlaying = true;
        isPaused = false;
        currentTime = 0.0; // Reset playback time
        
        return true;

    } catch (const std::exception& e) {
        std::cerr << "Error during PlayMedia: " << e.what() << std::endl;
        return false;
    }
}

// Pause and Resume Media Method
bool IController::PauseResumeMedia() {
    if (!isPlaying) {
        std::cerr << "No media is currently playing." << std::endl;
        return false;
    }

    if (isPaused) {
        Mix_ResumeMusic();
        isPaused = false;
    } else {
        Mix_PauseMusic();
        isPaused = true;
    }

    return true;
}

// Next Media Method
bool IController::NextMedia() {
    if (List_PL.empty() || currentPlaylistIndex >= List_PL.size()) {
        std::cerr << "No valid playlist selected." << std::endl;
        return false;
    }
    
    auto playlist = List_PL[currentPlaylistIndex];
    if (playlist->GetFiles().empty()) {
        std::cerr << "Current playlist is empty." << std::endl;
        return false;
    }
    
    size_t nextIndex = (currentIndex + 1) % playlist->GetFiles().size();
    return PlayMedia(currentPlaylistIndex, nextIndex);
}

// Previous Media Method
bool IController::PrevMedia() {
    if (List_PL.empty() || currentPlaylistIndex >= List_PL.size()) {
        std::cerr << "No valid playlist selected." << std::endl;
        return false;
    }
    
    auto playlist = List_PL[currentPlaylistIndex];
    if (playlist->GetFiles().empty()) {
        std::cerr << "Current playlist is empty." << std::endl;
        return false;
    }
    
    size_t prevIndex = (currentIndex > 0) ? (currentIndex - 1) : (playlist->GetFiles().size() - 1);
    return PlayMedia(currentPlaylistIndex, prevIndex);
}

// Update Current Directory
void IController::UpdateCurrentDirectory(const std::string& directoryPath) {
    try {
        // Assign the provided directory path to the currentDirectory attribute
        currentDirectory = directoryPath;
        
        // If we have a "Current Directory" playlist (index 0), update it
        if (!List_PL.empty()) {
            List_PL[0]->ClearFiles();
            AddMediaFilesFromFolder(0, currentDirectory);
        }
    } catch (const std::exception& e) {
        std::cerr << "Error updating current directory: " << e.what() << std::endl;
    }
}

// Add Playlist Method
bool IController::AddPlayList(const std::string& name) {
    try {
        // Create a new playlist
        auto playlist = std::make_shared<PlayList>(name);
        
        // Add it to the list of playlists
        List_PL.push_back(playlist);
        
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error adding playlist: " << e.what() << std::endl;
        return false;
    }
}

// Remove Playlist Method
bool IController::RemovePlayList(size_t index) {
    try {
        // Check if index is valid
        if (index >= List_PL.size() || index == 0) { // Don't allow removing the first playlist (Current Directory)
            std::cerr << "Invalid playlist index or attempting to remove Current Directory playlist." << std::endl;
            return false;
        }
        
        // Remove the playlist
        List_PL.erase(List_PL.begin() + index);
        
        // If we were playing from the removed playlist, stop playback
        if (currentPlaylistIndex == index) {
            if (currentMusic) {
                Mix_HaltMusic();
                Mix_FreeMusic(currentMusic);
                currentMusic = nullptr;
            }
            isPlaying = false;
            isPaused = false;
            
            // Reset indices
            currentPlaylistIndex = 0;
            currentIndex = 0;
        } else if (currentPlaylistIndex > index) {
            // Adjust currentPlaylistIndex if a playlist before it was removed
            currentPlaylistIndex--;
        }
        
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error removing playlist: " << e.what() << std::endl;
        return false;
    }
}

// Add To Playlist Method
bool IController::AddToPlayList(size_t playlistIndex, const std::string& filePath) {
    try {
        // Check if index is valid
        if (playlistIndex >= List_PL.size()) {
            std::cerr << "Invalid playlist index." << std::endl;
            return false;
        }
        
        // Check if file exists
        if (!std::filesystem::exists(filePath)) {
            std::cerr << "File does not exist: " << filePath << std::endl;
            return false;
        }
        
        // Add the file to the playlist
        List_PL[playlistIndex]->AddFile(filePath);
        
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error adding to playlist: " << e.what() << std::endl;
        return false;
    }
}

// Remove From Playlist Method
bool IController::RemoveFromPlayList(size_t playlistIndex, size_t mediaIndex) {
    try {
        // Check if playlist index is valid
        if (playlistIndex >= List_PL.size()) {
            std::cerr << "Invalid playlist index." << std::endl;
            return false;
        }
        
        // Check if media index is valid
        auto playlist = List_PL[playlistIndex];
        if (mediaIndex >= playlist->GetFiles().size()) {
            std::cerr << "Invalid media index." << std::endl;
            return false;
        }
        
        // Remove the file from the playlist
        playlist->RemoveFile(mediaIndex);
        
        // If we were playing the removed media, stop playback
        if (currentPlaylistIndex == playlistIndex && currentIndex == mediaIndex) {
            if (currentMusic) {
                Mix_HaltMusic();
                Mix_FreeMusic(currentMusic);
                currentMusic = nullptr;
            }
            isPlaying = false;
            isPaused = false;
            
            // If there are still files in the playlist, play the next one
            if (!playlist->GetFiles().empty()) {
                size_t newIndex = (currentIndex >= playlist->GetFiles().size()) ? 0 : currentIndex;
                PlayMedia(currentPlaylistIndex, newIndex);
            } else {
                // Reset index
                currentIndex = 0;
            }
        } else if (currentPlaylistIndex == playlistIndex && currentIndex > mediaIndex) {
            // Adjust currentIndex if a file before it was removed
            currentIndex--;
        }
        
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error removing from playlist: " << e.what() << std::endl;
        return false;
    }
}

// Add Media Files From Folder Method
bool IController::AddMediaFilesFromFolder(size_t playlistIndex, const std::string& folderPath) {
    try {
        // Check if index is valid
        if (playlistIndex >= List_PL.size()) {
            std::cerr << "Invalid playlist index." << std::endl;
            return false;
        }
        
        // Check if folder exists
        if (!std::filesystem::exists(folderPath) || !std::filesystem::is_directory(folderPath)) {
            std::cerr << "Folder does not exist: " << folderPath << std::endl;
            return false;
        }
        
        // Get the playlist
        auto playlist = List_PL[playlistIndex];
        
        // Iterate recursively over the directory and subdirectories
        for (const auto& entry : std::filesystem::recursive_directory_iterator(folderPath)) {
            if (entry.is_regular_file()) {
                // Check if the file has a valid media extension
                std::string extension = entry.path().extension().string();
                if (extension == ".mp3" || extension == ".wav") {
                    // Add the file to the playlist
                    playlist->AddFile(entry.path().string());
                }
            }
        }
        
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error adding media files from folder: " << e.what() << std::endl;
        return false;
    }
}

// Getter methods
size_t IController::GetCurrentPlaylistIndex() const {
    return currentPlaylistIndex;
}

size_t IController::GetCurrentMediaIndex() const {
    return currentIndex;
}

const std::vector<std::shared_ptr<PlayList>>& IController::GetPlaylists() {
    return List_PL;
}

const std::vector<std::shared_ptr<PlayList>>& IController::GetListOfPlayList() const {
    return List_PL;
}

bool IController::IsPlaying() const {
    return isPlaying;
}

bool IController::IsPaused() const {
    return isPaused;
}

void IController::Options() {
    if (centerView) {
        // Use the ShowMainMenu() for the main menu screen or ShowScreen() for feature screens
        centerView->ShowMainMenu();
    }
}

void IController::HandleCases() {
    // Base implementation does nothing
}

bool IController::ProcessMediaCommand(char command) {
    switch (command) {
        case 'p':
            return PauseResumeMedia();
        case 'n':
            return NextMedia();
        case 'b':
            return PrevMedia();
        default:
            return false;
    }
}

void IController::Set_View(std::shared_ptr<IView> view) {
    centerView = view;
}

std::shared_ptr<File> IController::GetCurrentMedia() const {
    if (List_PL.empty() || currentPlaylistIndex >= List_PL.size()) {
        return nullptr;
    }
    
    auto playlist = List_PL[currentPlaylistIndex];
    if (playlist->GetFiles().empty() || currentIndex >= playlist->GetFiles().size()) {
        return nullptr;
    }
    
    return playlist->GetFiles()[currentIndex];
}

std::shared_ptr<PlayList> IController::GetCurrentPlaylist() const {
    if (List_PL.empty() || currentPlaylistIndex >= List_PL.size()) {
        return nullptr;
    }
    
    return List_PL[currentPlaylistIndex];
}
