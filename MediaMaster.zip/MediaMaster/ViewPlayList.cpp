#include "ViewPlayList.hpp"
#include "IController.hpp"
#include "PlayList.hpp"
#include <iostream>

ViewPlayList::ViewPlayList(std::shared_ptr<IController> controller, int screenType, const std::string& prompt, size_t playlistIndex)
    : IView(controller), screenType(screenType), prompt(prompt), playlistIndex(playlistIndex) {
    // Nothing else to initialize
}

void ViewPlayList::ShowScreen() {
    // Clear the screen
    system("clear");
    
    std::cout << "=============================================== MEDIA PLAYER ===============================================" << std::endl;
    std::cout << std::endl;
    
    // Show appropriate content based on screen type
    switch (screenType) {
        case 1: // Show all playlists
            ShowAllPlaylists();
            break;
        case 2: // Show specific playlist
            ShowSpecificPlaylist(playlistIndex);
            break;
        case 3: // Show current directory
            ShowCurrentDirectory();
            break;
        case 8: // Add a playlist
            std::cout << prompt << std::endl;
            std::cout << std::endl;
            std::cout << "'0'. Return" << std::endl;
            break;
        case 97: // Add media to playlist
            std::cout << prompt << std::endl;
            std::cout << std::endl;
            std::cout << "'0'. Return" << std::endl;
            break;
        case 98: // Change current directory
            std::cout << prompt << std::endl;
            std::cout << std::endl;
            std::cout << "'0'. Return" << std::endl;
            break;
        default:
            std::cout << "Invalid screen type." << std::endl;
    }
    
    // Show current media information
    ShowCurrentMedia();
}

void ViewPlayList::ShowAllPlaylists() {
    // Show all playlists
    std::cout << "List of PlayList:" << std::endl;
    const auto& playlists = IController::GetPlaylists();
    for (size_t i = 0; i < playlists.size(); i++) {
        std::cout << "    " << i + 1 << ". " << playlists[i]->GetName() << " (" << playlists[i]->Size() << " files)" << std::endl;
    }
    
    std::cout << std::endl;
    std::cout << prompt << std::endl;
    std::cout << std::endl;
    std::cout << "'0'. Return" << std::endl;
}

void ViewPlayList::ShowSpecificPlaylist(size_t index) {
    // Show a specific playlist
    const auto& playlists = IController::GetPlaylists();
    if (index < playlists.size()) {
        std::cout << "List of Media in " << index + 1 << ". \"" << playlists[index]->GetName() << "\"" << std::endl;
        const auto& files = playlists[index]->GetFiles();
        for (size_t i = 0; i < files.size(); i++) {
            const auto& metadata = files[i]->getMetadata();
            std::string info = metadata.Title;
            if (info.empty()) {
                info = files[i]->getFileName();
            }
            if (!metadata.Artist.empty() && metadata.Artist != "Unknown") {
                info += " - " + metadata.Artist;
            }
            std::cout << "    " << i + 1 << ". " << info << std::endl;
        }
    } else {
        std::cout << "Invalid playlist index." << std::endl;
    }
    
    std::cout << std::endl;
    std::cout << "'0'. Return" << std::endl;
}

void ViewPlayList::ShowCurrentDirectory() {
    // Show media files in the current directory
    const auto& playlists = IController::GetPlaylists();
    if (!playlists.empty()) {
        std::cout << "Current directory media files:" << std::endl;
        const auto& files = playlists[0]->GetFiles();
        for (size_t i = 0; i < files.size(); i++) {
            const auto& metadata = files[i]->getMetadata();
            std::string info = metadata.Title;
            if (info.empty()) {
                info = files[i]->getFileName();
            }
            if (!metadata.Artist.empty() && metadata.Artist != "Unknown") {
                info += " - " + metadata.Artist;
            }
            std::cout << "    " << i + 1 << ". " << info << std::endl;
        }
    } else {
        std::cout << "No media files in current directory." << std::endl;
    }
    
    std::cout << std::endl;
    std::cout << "'0'. Return" << std::endl;
}
