#pragma once
#include "File.hpp"
#include "PlayList.hpp"
#include "IView.hpp"
#include <vector>
#include <memory>
// Forward declarations for SDL2 types to avoid including the headers
struct SDL_AudioSpec;
typedef struct _Mix_Music Mix_Music;
#include <iostream>
#include <filesystem>
#include <atomic>
#include <mutex>

/**
 * @class IController
 * @brief Base controller class for managing media files and metadata.
 */
class IController {
protected:
    // Static instance of IController for callback functions
    inline static IController* instance = nullptr;

    // Collection of playlists to manage
    static std::vector<std::shared_ptr<PlayList>> List_PL;
    
    // Current view
    std::shared_ptr<IView> centerView;

    // Index of the currently selected media file
    size_t currentIndex;
    
    // Index of the currently selected playlist
    size_t currentPlaylistIndex;

    // Pointer to the SDL2 music object for media playback
    Mix_Music* currentMusic;

    // Tracks current playback time in seconds
    double currentTime;

    // Flag to indicate if media is playing
    std::atomic<bool> isPlaying;

    // Flag to indicate if media is paused
    std::atomic<bool> isPaused;

    // The directory from which the program is executed
    std::string currentDirectory;

public:
    // Constructor and Destructor
    /**
     * @brief Default constructor that sets the current directory 
     *        and populates media files.
     */
    IController();

    /**
     * @brief Destructor to clean up resources.
     */
    virtual ~IController();

    // SDL2 Initialization Methods
    /**
     * @brief Initializes SDL and SDL_mixer for media playback.
     * @return True if initialization is successful, false otherwise.
     */
    bool InitializeSDL();

    // Playback Control Methods
    /**
     * @brief Starts playing the media file at the specified index from the specified playlist.
     * @param playlistIndex The index of the playlist.
     * @param mediaIndex The index of the media file in the playlist.
     * @return True if playback starts successfully, false otherwise.
     */
    bool PlayMedia(size_t playlistIndex, size_t mediaIndex);

    /**
     * @brief Callback method called when the currently playing media finishes.
     */
    void OnMediaFinished();

    /**
     * @brief Static callback function to handle the end of media playback.
     */
    static void StaticOnMediaFinished();

    /**
     * @brief Pauses or resumes the currently playing media file.
     * @return True if the operation is successful, false otherwise.
     */
    bool PauseResumeMedia();

    /**
     * @brief Moves to the next media file in the current playlist and starts playback.
     * @return True if the next media file is played successfully, false otherwise.
     */
    bool NextMedia();

    /**
     * @brief Moves to the previous media file in the current playlist and starts playback.
     * @return True if the previous media file is played successfully, false otherwise.
     */
    bool PrevMedia();

    // File and Directory Management Methods
    /**
     * @brief Updates the current directory and loads media files from it.
     * @param directoryPath Path to the directory to set as the current directory.
     */
    void UpdateCurrentDirectory(const std::string& directoryPath);

    /**
     * @brief Adds a new playlist with the specified name.
     * @param name The name of the playlist to add.
     * @return True if the playlist was successfully added, false otherwise.
     */
    bool AddPlayList(const std::string& name);

    /**
     * @brief Removes the playlist at the specified index.
     * @param index The index of the playlist to remove.
     * @return True if the playlist was successfully removed, false otherwise.
     */
    bool RemovePlayList(size_t index);

    /**
     * @brief Adds a media file to the specified playlist.
     * @param playlistIndex The index of the playlist to add the media file to.
     * @param filePath The path of the media file to add.
     * @return True if the media file was successfully added, false otherwise.
     */
    bool AddToPlayList(size_t playlistIndex, const std::string& filePath);

    /**
     * @brief Removes a media file from the specified playlist.
     * @param playlistIndex The index of the playlist to remove the media file from.
     * @param mediaIndex The index of the media file to remove.
     * @return True if the media file was successfully removed, false otherwise.
     */
    bool RemoveFromPlayList(size_t playlistIndex, size_t mediaIndex);

    /**
     * @brief Adds media files from a folder and its subfolders to a playlist.
     * @param playlistIndex The index of the playlist to add the media files to.
     * @param folderPath Path to the folder containing media files.
     * @return True if files were successfully added, false otherwise.
     */
    bool AddMediaFilesFromFolder(size_t playlistIndex, const std::string& folderPath);

    /**
     * @brief Returns the current playlist index.
     * @return The index of the current playlist.
     */
    size_t GetCurrentPlaylistIndex() const;

    /**
     * @brief Returns the current media index.
     * @return The index of the current media file.
     */
    size_t GetCurrentMediaIndex() const;

    /**
     * @brief Returns a reference to the List_PL vector.
     * @return Reference to the List_PL vector.
     */
    static const std::vector<std::shared_ptr<PlayList>>& GetPlaylists();
    
    /**
     * @brief Returns a reference to the List_PL vector (non-static version).
     * @return Reference to the List_PL vector.
     */
    const std::vector<std::shared_ptr<PlayList>>& GetListOfPlayList() const;

    /**
     * @brief Returns whether media is currently playing.
     * @return True if media is playing, false otherwise.
     */
    bool IsPlaying() const;

    /**
     * @brief Returns whether media is currently paused.
     * @return True if media is paused, false otherwise.
     */
    bool IsPaused() const;

    /**
     * @brief Updates the view based on the current state.
     */
    virtual void Options();

    /**
     * @brief Handles user input based on the current screen.
     */
    virtual void HandleCases();

    /**
     * @brief Processes a key command for media playback.
     * @param command The key command to process.
     * @return True if the command was successfully processed, false otherwise.
     */
    bool ProcessMediaCommand(char command);

    /**
     * @brief Sets the center view for the controller.
     * @param view The view to set as the center view.
     */
    void Set_View(std::shared_ptr<IView> view);

    /**
     * @brief Gets the currently playing media file.
     * @return A pointer to the currently playing media file, or nullptr if no media is playing.
     */
    std::shared_ptr<File> GetCurrentMedia() const;

    /**
     * @brief Gets the currently active playlist.
     * @return A pointer to the currently active playlist, or nullptr if no playlist is active.
     */
    std::shared_ptr<PlayList> GetCurrentPlaylist() const;
};
