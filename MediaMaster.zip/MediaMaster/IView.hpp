#pragma once
#include <memory>

// Forward declarations
class IController;
class PlayList;
class File;

/**
 * @class IView
 * @brief Base interface for all views.
 */
class IView {
protected:
    std::shared_ptr<IController> controller;

public:
    /**
     * @brief Constructor that initializes the view with a controller.
     * @param controller The controller for this view.
     */
    IView(std::shared_ptr<IController> controller);

    /**
     * @brief Virtual destructor.
     */
    virtual ~IView() = default;

    /**
     * @brief Shows the screen for this view.
     * The top half displays use case specific content.
     * The bottom half shows current media info via ShowCurrentMedia().
     */
    virtual void ShowScreen() = 0;
    
    /**
     * @brief Shows the main menu.
     * Used for the main menu display.
     */
    virtual void ShowMainMenu();

    /**
     * @brief Shows information about the currently playing media.
     */
    void ShowCurrentMedia();

    /**
     * @brief Formats a duration in seconds to a string in MM:SS format.
     * @param seconds The duration in seconds.
     * @return The formatted duration string.
     */
    std::string FormatDuration(double seconds) const;

    /**
     * @brief Gets the controller for this view.
     * @return The controller for this view.
     */
    std::shared_ptr<IController> GetController() const;
};
