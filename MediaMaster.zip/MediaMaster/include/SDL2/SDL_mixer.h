#ifndef SDL_MIXER_H_
#define SDL_MIXER_H_

#include <SDL2/SDL.h>
#include <SDL2/SDL_rwops.h>
#include <SDL2/SDL_audio.h>
#include <SDL2/SDL_endian.h>
#include <SDL2/SDL_version.h>
#include <SDL2/begin_code.h>

// Define missing constants
#define MIX_DEFAULT_FORMAT AUDIO_S16LSB

// Forward declarations
typedef struct _Mix_Music Mix_Music;

// Function prototypes with extern "C" for C++ compatibility
#ifdef __cplusplus
extern "C" {
#endif

// Basic initialization and cleanup
extern int Mix_OpenAudio(int frequency, unsigned short format, int channels, int chunksize);
extern void Mix_CloseAudio(void);
extern const char* Mix_GetError(void);

// Music loading and playing
extern Mix_Music* Mix_LoadMUS(const char* file);
extern void Mix_FreeMusic(Mix_Music* music);
extern int Mix_PlayMusic(Mix_Music* music, int loops);
extern void Mix_HaltMusic(void);
extern void Mix_PauseMusic(void);
extern void Mix_ResumeMusic(void);
extern void Mix_HookMusicFinished(void (*music_finished)(void));

#ifdef __cplusplus
}
#endif

#include <SDL2/close_code.h>
#endif /* SDL_MIXER_H_ */
