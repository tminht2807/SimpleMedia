#include "PlayList.hpp"
#include <iostream>
#include <filesystem>

PlayList::PlayList(const std::string& name) : Name(name) {
    // Nothing else to initialize
}

std::string PlayList::GetName() const {
    return Name;
}

void PlayList::SetName(const std::string& name) {
    Name = name;
}

const std::vector<std::shared_ptr<File>>& PlayList::GetFiles() const {
    return ListFiles;
}

bool PlayList::AddFile(const std::string& filePath) {
    try {
        // Check if file exists
        if (!std::filesystem::exists(filePath)) {
            std::cerr << "File does not exist: " << filePath << std::endl;
            return false;
        }

        // Check if file extension is supported
        std::string extension = std::filesystem::path(filePath).extension().string();
        if (extension != ".mp3" && extension != ".wav") {
            std::cerr << "Unsupported file format: " << extension << std::endl;
            return false;
        }

        // Check if file is already in the playlist
        for (const auto& file : ListFiles) {
            if (file->getFilePath() == filePath) {
                std::cerr << "File already in playlist: " << filePath << std::endl;
                return false;
            }
        }

        // Create a File object
        std::shared_ptr<File> file = std::make_shared<File>(filePath);

        // Add the file to the playlist
        ListFiles.push_back(file);

        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error adding file to playlist: " << e.what() << std::endl;
        return false;
    }
}

bool PlayList::RemoveFile(size_t index) {
    try {
        // Check if index is valid
        if (index >= ListFiles.size()) {
            std::cerr << "Invalid file index: " << index << std::endl;
            return false;
        }

        // Remove the file from the playlist
        ListFiles.erase(ListFiles.begin() + index);

        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error removing file from playlist: " << e.what() << std::endl;
        return false;
    }
}

void PlayList::ClearFiles() {
    ListFiles.clear();
}

size_t PlayList::Size() const {
    return ListFiles.size();
}

bool PlayList::IsEmpty() const {
    return ListFiles.empty();
}
