#pragma once
#include <string>

/**
 * @struct MetadataMP3
 * @brief Structure to store metadata for MP3 files.
 */
struct MetadataMP3 {
    std::string Title;
    std::string Artist;
    std::string Album;
    std::string Year;
    std::string Comment;
    std::string Genre;
    double Duration; // Duration in seconds
};

/**
 * @class File
 * @brief Class to represent a media file and its metadata.
 */
class File {
private:
    std::string File_path;
    MetadataMP3 metadata;

public:
    /**
     * @brief Constructor that initializes the file path and reads metadata.
     * @param filePath The path to the media file.
     */
    File(const std::string& filePath);

    /**
     * @brief Gets the file path.
     * @return The path to the media file.
     */
    std::string getFilePath() const;
    
    /**
     * @brief Gets the file name without path.
     * @return The file name.
     */
    std::string getFileName() const;

    /**
     * @brief Gets the metadata of the media file.
     * @return The metadata of the media file.
     */
    MetadataMP3 getMetadata() const;

    /**
     * @brief Sets the file path and reads metadata.
     * @param filePath The new path to the media file.
     */
    void setFilePath(const std::string& filePath);

    /**
     * @brief Sets the metadata of the media file.
     * @param metadata The new metadata to set.
     */
    void setMetadata(const MetadataMP3& metadata);
};
