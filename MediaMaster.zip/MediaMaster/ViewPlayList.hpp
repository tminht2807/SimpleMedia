#pragma once
#include "IView.hpp"
#include <string>

/**
 * @class ViewPlayList
 * @brief View for displaying and interacting with playlists.
 */
class ViewPlayList : public IView {
private:
    int screenType; // 1: Show all playlists, 2: Show specific playlist, etc.
    std::string prompt; // Custom prompt message
    size_t playlistIndex; // Index of the playlist to display (if applicable)

public:
    /**
     * @brief Constructor that initializes the view with a controller, screen type, and prompt.
     * @param controller The controller for this view.
     * @param screenType The type of playlist screen to show.
     * @param prompt Custom prompt message.
     * @param playlistIndex Index of the playlist to display (if applicable).
     */
    ViewPlayList(std::shared_ptr<IController> controller, int screenType, const std::string& prompt, size_t playlistIndex = 0);

    /**
     * @brief Shows the appropriate playlist screen based on the screen type.
     */
    void ShowScreen() override;

private:
    /**
     * @brief Shows all playlists in the media library.
     */
    void ShowAllPlaylists();

    /**
     * @brief Shows a specific playlist.
     * @param index The index of the playlist to show.
     */
    void ShowSpecificPlaylist(size_t index);

    /**
     * @brief Shows all media files in the current directory.
     */
    void ShowCurrentDirectory();
};
