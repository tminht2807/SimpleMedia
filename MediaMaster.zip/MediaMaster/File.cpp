#include "File.hpp"
#include <taglib/fileref.h>
#include <taglib/tag.h>
#include <taglib/audioproperties.h>
#include <filesystem>

// Constructor
File::File(const std::string& filePath) : File_path(filePath) {
    try {
        // Check if file exists
        if (!std::filesystem::exists(filePath)) {
            throw std::runtime_error("File does not exist: " + filePath);
        }

        // Use TagLib to read metadata
        TagLib::FileRef fileRef(filePath.c_str());
        if (!fileRef.isNull() && fileRef.tag()) {
            TagLib::Tag* tag = fileRef.tag();
            metadata.Title = tag->title().to8Bit(true);
            metadata.Artist = tag->artist().to8Bit(true);
            metadata.Album = tag->album().to8Bit(true);
            metadata.Year = std::to_string(tag->year());
            metadata.Comment = tag->comment().to8Bit(true);
            metadata.Genre = tag->genre().to8Bit(true);

            // Read duration using audio properties
            if (fileRef.audioProperties()) {
                metadata.Duration = fileRef.audioProperties()->lengthInSeconds();
            } else {
                metadata.Duration = 0.0; // Default to 0 if duration is unavailable
            }
        } else {
            // Set default values if metadata couldn't be read
            metadata.Title = std::filesystem::path(filePath).filename().string();
            metadata.Artist = "Unknown";
            metadata.Album = "Unknown";
            metadata.Year = "Unknown";
            metadata.Comment = "Unknown";
            metadata.Genre = "Unknown";
            metadata.Duration = 0.0;
        }
    } catch (const std::exception& e) {
        std::cerr << "Error reading file metadata: " << e.what() << std::endl;
        // Set default values in case of error
        metadata.Title = std::filesystem::path(filePath).filename().string();
        metadata.Artist = "Unknown";
        metadata.Album = "Unknown";
        metadata.Year = "Unknown";
        metadata.Comment = "Unknown";
        metadata.Genre = "Unknown";
        metadata.Duration = 0.0;
    }
}

// Getter for File_path
std::string File::getFilePath() const {
    return File_path;
}

std::string File::getFileName() const {
    // Extract filename from the full path
    size_t lastSlash = File_path.find_last_of("/\\");
    if (lastSlash != std::string::npos) {
        return File_path.substr(lastSlash + 1);
    }
    return File_path; // Return the full path if no slash found
}

// Getter for Metadata
MetadataMP3 File::getMetadata() const {
    return metadata;
}

// Setter for File_path
void File::setFilePath(const std::string& filePath) {
    File_path = filePath;

    try {
        // Check if file exists
        if (!std::filesystem::exists(filePath)) {
            throw std::runtime_error("File does not exist: " + filePath);
        }

        // Update metadata when File_path is changed
        TagLib::FileRef fileRef(filePath.c_str());
        if (!fileRef.isNull() && fileRef.tag()) {
            TagLib::Tag* tag = fileRef.tag();
            metadata.Title = tag->title().to8Bit(true);
            metadata.Artist = tag->artist().to8Bit(true);
            metadata.Album = tag->album().to8Bit(true);
            metadata.Year = std::to_string(tag->year());
            metadata.Comment = tag->comment().to8Bit(true);
            metadata.Genre = tag->genre().to8Bit(true);

            // Read duration using audio properties
            if (fileRef.audioProperties()) {
                metadata.Duration = fileRef.audioProperties()->lengthInSeconds();
            } else {
                metadata.Duration = 0.0; // Default to 0 if duration is unavailable
            }
        } else {
            // Set default values if metadata couldn't be read
            metadata.Title = std::filesystem::path(filePath).filename().string();
            metadata.Artist = "Unknown";
            metadata.Album = "Unknown";
            metadata.Year = "Unknown";
            metadata.Comment = "Unknown";
            metadata.Genre = "Unknown";
            metadata.Duration = 0.0;
        }
    } catch (const std::exception& e) {
        std::cerr << "Error updating file metadata: " << e.what() << std::endl;
        // Set default values in case of error
        metadata.Title = std::filesystem::path(filePath).filename().string();
        metadata.Artist = "Unknown";
        metadata.Album = "Unknown";
        metadata.Year = "Unknown";
        metadata.Comment = "Unknown";
        metadata.Genre = "Unknown";
        metadata.Duration = 0.0;
    }
}

// Setter for Metadata
void File::setMetadata(const MetadataMP3& newMetadata) {
    metadata = newMetadata;
}
