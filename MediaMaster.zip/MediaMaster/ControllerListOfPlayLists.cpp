#include "ControllerListOfPlayLists.hpp"
#include "ViewPlayList.hpp"
#include "ViewListOfPlayList.hpp"
#include "ControllerPlayList.hpp"
#include <iostream>
#include <string>
#include <limits>
#include <memory>

ControllerListOfPlayLists::ControllerListOfPlayLists() : IController() {
    // Nothing else to initialize
}

ControllerListOfPlayLists::~ControllerListOfPlayLists() {
    // Nothing to clean up
}

void ControllerListOfPlayLists::HandleCases() {
    char choice;
    bool exitMenu = false;
    
    // Return to main menu when '0' is entered
    while (!exitMenu) {
        // Show menu screen
        std::cout << "=============================================== MEDIA PLAYER ===============================================" << std::endl;
        std::cout << std::endl;
        std::cout << "Media Library Options:" << std::endl;
        std::cout << "'1'. Play from current directory" << std::endl;
        std::cout << "'3'. Play a PlayList" << std::endl;
        std::cout << "'5'. Show a PlayList" << std::endl;
        std::cout << "'6'. Show Media Library" << std::endl;
        std::cout << "'7'. Delete a PlayList from Media Library" << std::endl;
        std::cout << "'8'. Add a PlayList to Media Library" << std::endl;
        std::cout << "'a'. Add Media to PlayList in Media Library" << std::endl;
        std::cout << "'r'. Remove Media from PlayList in Media Library" << std::endl;
        std::cout << std::endl;
        std::cout << "'0'. Return to Main Menu" << std::endl;
        std::cout << std::endl;
        
        // Show current media information
        std::cout << "=============================================== CURRENT MEDIA ===============================================" << std::endl;
        
        auto currentPlaylist = GetCurrentPlaylist();
        auto currentMedia = GetCurrentMedia();
        
        std::cout << "Current Playing From PlayList: " << GetCurrentPlaylistIndex() << ". \"" 
                << (currentPlaylist ? currentPlaylist->GetName() : "Unknown") << "\"" << std::endl;
        
        std::cout << "PlayList Media:" << std::endl;
        if (currentPlaylist && !currentPlaylist->GetFiles().empty()) {
            const auto& files = currentPlaylist->GetFiles();
            for (size_t i = 0; i < files.size(); ++i) {
                std::cout << "    " << i + 1 << ". " << files[i]->getFileName() << std::endl;
            }
        } else {
            std::cout << "    No media in playlist" << std::endl;
        }
        
        std::cout << std::endl;
        std::cout << "Current Media: " << GetCurrentMediaIndex() + 1 << ". \"" 
                << (currentMedia ? currentMedia->getFileName() : "None") << "\"" << std::endl;
        
        std::cout << "Metadata: " << std::endl;
        
        std::cout << "    'p': Pause/Resume" << std::endl;
        std::cout << "    'n': next in PlayList" << std::endl;
        std::cout << "    'b': previous in PlayList" << std::endl;
        
        std::cout << ">> Enter: ";
        
        std::cin >> choice;
        
        if (choice == '0') {
            exitMenu = true;
        } else {
            switch (choice) {
                case '1': // Play from current directory
                    PlayCurrentDirectory();
                    break;
                case '3': // Play a PlayList
                    PlayPlayList();
                    break;
                case '5': // Show a PlayList from Media Library
                    ShowPlayList();
                    break;
                case '6': // Show Media Library
                    {
                        // Create a new view directly here instead of in ShowListOfPlayLists
                        std::cout << "=============================================== MEDIA PLAYER ===============================================" << std::endl;
                        std::cout << std::endl;
                        std::cout << "Media Library (PlayLists):" << std::endl;
                        
                        // Get playlists
                        const auto& playlists = GetListOfPlayList();
                        
                        // Display the list of playlists
                        if (playlists.empty()) {
                            std::cout << "No playlists available." << std::endl;
                        } else {
                            for (size_t i = 0; i < playlists.size(); ++i) {
                                std::cout << i + 1 << ". " << playlists[i]->GetName() << std::endl;
                            }
                        }
                        
                        std::cout << std::endl;
                        std::cout << "'0'. Return to Main Menu" << std::endl;
                        
                        // Show current media information
                        std::cout << "=============================================== CURRENT MEDIA ===============================================" << std::endl;
                        
                        auto currentPlaylist = GetCurrentPlaylist();
                        auto currentMedia = GetCurrentMedia();
                        
                        std::cout << "Current Playing From PlayList: " << GetCurrentPlaylistIndex() << ". \"" 
                                << (currentPlaylist ? currentPlaylist->GetName() : "Unknown") << "\"" << std::endl;
                        
                        std::cout << "PlayList Media:" << std::endl;
                        if (currentPlaylist && !currentPlaylist->GetFiles().empty()) {
                            const auto& files = currentPlaylist->GetFiles();
                            for (size_t i = 0; i < files.size(); ++i) {
                                std::cout << "    " << i + 1 << ". " << files[i]->getFileName() << std::endl;
                            }
                        } else {
                            std::cout << "    No media in playlist" << std::endl;
                        }
                        
                        std::cout << std::endl;
                        std::cout << "Current Media: " << GetCurrentMediaIndex() + 1 << ". \"" 
                                << (currentMedia ? currentMedia->getFileName() : "None") << "\"" << std::endl;
                        
                        std::cout << "Metadata: " << std::endl;
                        
                        std::cout << "    'p': Pause/Resume" << std::endl;
                        std::cout << "    'n': next in PlayList" << std::endl;
                        std::cout << "    'b': previous in PlayList" << std::endl;
                        
                        // Wait for user input to return to main menu
                        char choice;
                        std::cout << ">> Press any key to continue (press 0 to return to main menu): ";
                        std::cin >> choice;
                        if (choice != '0') {
                            // Just continue to main menu
                            std::cout << "Returning to main menu..." << std::endl;
                        }
                    }
                    break;
                case '7': // Delete a PlayList from Media Library
                    RemovePlayList();
                    break;
                case '8': // Add a PlayList to Media Library
                    AddPlayList();
                    break;
                case 'a': // add Media to PlayList in Media Library
                    AddMediaToPlayList();
                    break;
                case 'r': // remove Media from PlayList in Media Library
                    RemoveMediaFromPlayList();
                    break;
                case 'p': // Handle media commands
                case 'n':
                case 'b':
                    ProcessMediaCommand(choice);
                    break;
                default:
                    std::cerr << "Invalid choice in ControllerListOfPlayLists." << std::endl;
            }
        }
    }
}

void ControllerListOfPlayLists::ShowListOfPlayLists() {
    // Display the list of playlists directly without using a view
    std::cout << "=============================================== MEDIA PLAYER ===============================================" << std::endl;
    std::cout << std::endl;
    std::cout << "Media Library (PlayLists):" << std::endl;
    
    // Get playlists
    const auto& playlists = GetListOfPlayList();
    
    // Display the list of playlists
    if (playlists.empty()) {
        std::cout << "No playlists available." << std::endl;
    } else {
        for (size_t i = 0; i < playlists.size(); ++i) {
            std::cout << i + 1 << ". " << playlists[i]->GetName() << std::endl;
        }
    }
    
    std::cout << std::endl;
    std::cout << "'0'. Return to Main Menu" << std::endl;
    
    // Show current media information
    std::cout << "=============================================== CURRENT MEDIA ===============================================" << std::endl;
    
    auto currentPlaylist = GetCurrentPlaylist();
    auto currentMedia = GetCurrentMedia();
    
    std::cout << "Current Playing From PlayList: " << GetCurrentPlaylistIndex() << ". \"" 
              << (currentPlaylist ? currentPlaylist->GetName() : "Unknown") << "\"" << std::endl;
    
    std::cout << "PlayList Media:" << std::endl;
    if (currentPlaylist && !currentPlaylist->GetFiles().empty()) {
        const auto& files = currentPlaylist->GetFiles();
        for (size_t i = 0; i < files.size(); ++i) {
            std::cout << "    " << i + 1 << ". " << files[i]->getFileName() << std::endl;
        }
    } else {
        std::cout << "    No media in playlist" << std::endl;
    }
    
    std::cout << std::endl;
    std::cout << "Current Media: " << GetCurrentMediaIndex() + 1 << ". \"" 
              << (currentMedia ? currentMedia->getFileName() : "None") << "\"" << std::endl;
    
    std::cout << "Metadata: " << std::endl;
    
    std::cout << "    'p': Pause/Resume" << std::endl;
    std::cout << "    'n': next in PlayList" << std::endl;
    std::cout << "    'b': previous in PlayList" << std::endl;
    
    // Wait for user input to return to main menu
    char choice;
    std::cout << ">> Enter: ";
    std::cin >> choice;
}

void ControllerListOfPlayLists::AddPlayList() {
    // First, setup the view for the add playlist screen
    system("clear");
    
    // Set up the view with screen type 8 for Add Playlist
    auto view = std::make_shared<ViewListOfPlayList>(
        std::shared_ptr<IController>(this, [](IController*){/* Non-owning shared_ptr */}),
        8, // Screen type 8 for Add Playlist
        "Enter name for the new PlayList"
    );
    
    // Set the view
    Set_View(view);
    
    // Show the screen using the view
    if (centerView) {
        centerView->ShowScreen();
    }
    
    // Get user input for the playlist name
    std::string name;
    
    // Clear the buffer only if there are characters to clear
    if (std::cin.rdbuf()->in_avail() > 0) {
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    
    std::getline(std::cin, name);
    
    if (name == "0") {
        // Return to main menu
        return;
    }
    
    // Add the playlist
    bool success = false;
    if (!name.empty()) {
        success = IController::AddPlayList(name);
    }
    
    // Show result
    system("clear");
    
    // Update view with result message
    auto resultView = std::make_shared<ViewListOfPlayList>(
        std::shared_ptr<IController>(this, [](IController*){/* Non-owning shared_ptr */}),
        8, // Still screen type 8
        success ? "Successfully added playlist: " + name : "Failed to add playlist."
    );
    
    // Set the view
    Set_View(resultView);
    
    // Show the result
    if (centerView) {
        centerView->ShowScreen();
    }
    
    // Wait for user input to continue
    std::cout << "Press Enter to continue..." << std::endl;
    
    // Only wait for input if there's no leftover in the buffer
    if (std::cin.rdbuf()->in_avail() == 0) {
        std::cin.get();
    }
}

void ControllerListOfPlayLists::RemovePlayList() {
    // Create and set the view
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        1, // Show all playlists
        "Enter Index of PlayList to delete:",
        0
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    int playlistIndex;
    std::cin >> playlistIndex;
    
    if (playlistIndex == 0) {
        // Return to main menu
        return;
    }
    
    // Adjust index (UI shows 1-based, internal is 0-based)
    playlistIndex--;
    
    // Remove the playlist
    if (playlistIndex >= 0 && playlistIndex < static_cast<int>(List_PL.size())) {
        if (IController::RemovePlayList(playlistIndex)) {
            std::cout << "Successfully removed playlist." << std::endl;
        } else {
            std::cerr << "Failed to remove playlist." << std::endl;
        }
    } else {
        std::cerr << "Invalid playlist index." << std::endl;
    }
}

void ControllerListOfPlayLists::PlayPlayList() {
    // Create and set the view
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        1, // Show all playlists
        "Enter Index of PlayList to play:",
        0
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    int playlistIndex;
    std::cin >> playlistIndex;
    
    if (playlistIndex == 0) {
        // Return to main menu
        return;
    }
    
    // Adjust index (UI shows 1-based, internal is 0-based)
    playlistIndex--;
    
    // Check if index is valid
    if (playlistIndex >= 0 && playlistIndex < static_cast<int>(List_PL.size())) {
        // Switch to ControllerPlayList to handle playing from the selected playlist
        auto playlistController = std::make_shared<ControllerPlayList>();
        playlistController->PlayFromPlayList(playlistIndex);
    } else {
        std::cerr << "Invalid playlist index." << std::endl;
    }
}

void ControllerListOfPlayLists::ShowPlayList() {
    // Create and set the view
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        1, // Show all playlists
        "Enter Index of PlayList to show:",
        0
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    int playlistIndex;
    std::cin >> playlistIndex;
    
    if (playlistIndex == 0) {
        // Return to main menu
        return;
    }
    
    // Adjust index (UI shows 1-based, internal is 0-based)
    playlistIndex--;
    
    // Check if index is valid
    if (playlistIndex >= 0 && playlistIndex < static_cast<int>(List_PL.size())) {
        // Switch to ControllerPlayList to handle showing the selected playlist
        auto playlistController = std::make_shared<ControllerPlayList>();
        playlistController->ShowPlayList(playlistIndex);
    } else {
        std::cerr << "Invalid playlist index." << std::endl;
    }
}

void ControllerListOfPlayLists::AddMediaToPlayList() {
    // Create and set the view
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        1, // Show all playlists
        "Enter Index of PlayList to add Media:",
        0
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    int playlistIndex;
    std::cin >> playlistIndex;
    
    if (playlistIndex == 0) {
        // Return to main menu
        return;
    }
    
    // Adjust index (UI shows 1-based, internal is 0-based)
    playlistIndex--;
    
    // Check if index is valid
    if (playlistIndex >= 0 && playlistIndex < static_cast<int>(List_PL.size())) {
        // Switch to ControllerPlayList to handle adding media to the selected playlist
        auto playlistController = std::make_shared<ControllerPlayList>();
        playlistController->AddToPlayList(playlistIndex);
    } else {
        std::cerr << "Invalid playlist index." << std::endl;
    }
}

void ControllerListOfPlayLists::RemoveMediaFromPlayList() {
    // Create and set the view
    auto view = std::make_shared<ViewPlayList>(
        std::shared_ptr<IController>(this, [](IController*){}),
        1, // Show all playlists
        "Enter Index of PlayList to remove Media:",
        0
    );
    Set_View(view);
    
    // Show the view
    Options();
    
    // Get user input
    int playlistIndex;
    std::cin >> playlistIndex;
    
    if (playlistIndex == 0) {
        // Return to main menu
        return;
    }
    
    // Adjust index (UI shows 1-based, internal is 0-based)
    playlistIndex--;
    
    // Check if index is valid
    if (playlistIndex >= 0 && playlistIndex < static_cast<int>(List_PL.size())) {
        // Switch to ControllerPlayList to handle removing media from the selected playlist
        auto playlistController = std::make_shared<ControllerPlayList>();
        playlistController->RemoveFromPlayList(playlistIndex);
    } else {
        std::cerr << "Invalid playlist index." << std::endl;
    }
}

void ControllerListOfPlayLists::PlayCurrentDirectory() {
    // Check if the current directory playlist exists (PlayList 0)
    if (List_PL.empty()) {
        std::cerr << "No playlists available." << std::endl;
        return;
    }
    
    // Switch to ControllerPlayList to handle playing from the current directory
    auto playlistController = std::make_shared<ControllerPlayList>();
    playlistController->PlayFromPlayList(0); // Play from playlist 0 (current directory)
}
