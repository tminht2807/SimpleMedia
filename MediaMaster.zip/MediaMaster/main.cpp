#include "IController.hpp"
#include "ControllerListOfPlayLists.hpp"
#include "ControllerPlayList.hpp"
#include "ViewListOfPlayList.hpp"
#include "ViewPlayList.hpp"
#include <iostream>
#include <memory>
#include <typeinfo>

// Global controller pointer that persists throughout the program
static IController* g_controller = nullptr;

/**
 * @brief Main function that initializes the application and handles the main loop.
 * @return 0 if the program exits normally, 1 otherwise.
 */
int main() {
    try {
        // Create the main controller for the application with its corresponding view
        auto listController = new ControllerListOfPlayLists();
        g_controller = listController;  // Store in global variable for persistence
        
        // Create main view and set it to the controller
        auto mainView = std::make_shared<ViewListOfPlayList>(
            std::shared_ptr<IController>(g_controller, [](IController*){/* Non-owning shared_ptr */}),
            0, // Main view type
            ""  // No message
        );
        g_controller->Set_View(mainView);
        
        char choice;
        while (true) {
            // Show the main menu using the view (controller calls view's methods)
            g_controller->Options(); // This calls view->ShowMainMenu()
            
            // Get user input
            std::cin >> choice;
            
            // Process media control commands
            if (choice == 'p' || choice == 'n' || choice == 'b') {
                g_controller->ProcessMediaCommand(choice);
                continue;
            }
            
            // Process main menu options
            switch (choice) {
                case '0': // Exit
                    std::cout << "Exiting program." << std::endl;
                    delete g_controller;  // Clean up
                    return 0;
                    
                case '1': // Play from current directory
                {
                    auto controller = dynamic_cast<ControllerListOfPlayLists*>(g_controller);
                    if (controller) {
                        controller->PlayCurrentDirectory();
                    }
                    break;
                }
                    
                case '2': // Play a media in Current Playing List
                {
                    size_t index = g_controller->GetCurrentPlaylistIndex();
                    
                    // Create new controller and view as a pair
                    auto controller = new ControllerPlayList();
                    
                    // Create corresponding view
                    auto view = std::make_shared<ViewPlayList>(
                        std::shared_ptr<IController>(controller, [](IController*){/* Non-owning shared_ptr */}),
                        2, // Show specific playlist view type 
                        "Select media to play:",
                        index
                    );
                    
                    // Set the view on the controller
                    controller->Set_View(view);
                    
                    // Replace the global controller
                    delete g_controller;
                    g_controller = controller;
                    
                    // Call the controller to handle this specific use case
                    controller->PlayFromPlayList(index);
                    break;
                }
                
                case '3': // Play a PlayList
                case '5': // Show a PlayList from Media Library
                case '6': // Show Media Library
                case '7': // Delete a PlayList from Media Library
                case '8': // Add a PlayList to Media Library
                case 'a': // add Media to PlayList in Media Library
                case 'r': // remove Media from PlayList in Media Library
                {
                    auto controller = dynamic_cast<ControllerListOfPlayLists*>(g_controller);
                    if (!controller) {
                        // Create new controller and view as a pair
                        controller = new ControllerListOfPlayLists();
                        
                        // Create corresponding view
                        auto view = std::make_shared<ViewListOfPlayList>(
                            std::shared_ptr<IController>(controller, [](IController*){/* Non-owning shared_ptr */}),
                            1, // List view type
                            ""  // No message
                        );
                        
                        // Set the view
                        controller->Set_View(view);
                        
                        // Replace global controller
                        delete g_controller;
                        g_controller = controller;
                    }
                    
                    // Handle the specific use case by delegating to controller
                    switch (choice) {
                        case '3': // Play a PlayList
                            controller->PlayPlayList();
                            break;
                        case '5': // Show a PlayList from Media Library
                            controller->ShowPlayList();
                            break;
                        case '6': // Show Media Library
                            controller->ShowListOfPlayLists();
                            break;
                        case '7': // Delete a PlayList from Media Library
                            controller->RemovePlayList();
                            break;
                        case '8': // Add a PlayList to Media Library
                            controller->AddPlayList();
                            break;
                        case 'a': // add Media to PlayList in Media Library
                            controller->AddMediaToPlayList();
                            break;
                        case 'r': // remove Media from PlayList in Media Library
                            controller->RemoveMediaFromPlayList();
                            break;
                    }
                    break;
                }
                
                case '4': // Show current directory
                case 'c': // change current directory
                {
                    auto controller = dynamic_cast<ControllerPlayList*>(g_controller);
                    if (!controller) {
                        // Create new controller and view as a pair
                        controller = new ControllerPlayList();
                        
                        // Create corresponding view
                        auto view = std::make_shared<ViewPlayList>(
                            std::shared_ptr<IController>(controller, [](IController*){/* Non-owning shared_ptr */}),
                            3, // Current directory view type
                            "Current directory:",
                            0  // Playlist index 0 (current directory)
                        );
                        
                        // Set the view
                        controller->Set_View(view);
                        
                        // Replace global controller
                        delete g_controller;
                        g_controller = controller;
                    }
                    
                    // Handle the specific use case
                    if (choice == '4') {
                        controller->ShowCurrentDirectory();
                    } else {
                        controller->ChangeDirectory();
                    }
                    break;
                }
                
                default:
                    std::cerr << "Invalid choice. Please try again." << std::endl;
            }
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        delete g_controller;  // Clean up
        return 1;
    }
}
